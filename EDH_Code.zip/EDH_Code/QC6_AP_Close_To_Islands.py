#Script Name:                   QC6_AP_Close_To_Islands.py
#Corresponding Script Tool:     QC6 AP Close To Islands
#Purpose:                       Looks for APs that are within a certain distance of the islands found by QC2
#Author:                        Gardner Pierson, North Carolina State University, 03/8/2021

import sys,os,arcpy,datetime
arcpy.env.overwriteOutput=True

# Script arguments
EDHwksp=sys.argv[1]#EDH_workspace
distValue=sys.argv[2]

### Setting up the workspace
EDHmain=os.path.join(EDHwksp, "EDH_QC_Evaluation.gdb")
EDHgdb=os.path.join(EDHwksp, "EDH_QC_Assessment_TempDir/tempQC6.gdb")
arcpy.env.workspace= EDHgdb
arcpy.AddMessage('Workspace Set')

### Analysis
# Process: Select APs that are too Close to Islands
apTooClose=os.path.join(EDHmain, "QC5_AP_Too_Close_all")
islandsSelect=os.path.join(EDHmain, "QC2_Islands")
apTooCloseLyr=os.path.join(EDHmain, "AP_Too_Close_all_lyr")
arcpy.MakeFeatureLayer_management(apTooClose, apTooCloseLyr) 
arcpy.SelectLayerByLocation_management(apTooCloseLyr, "WITHIN_A_DISTANCE", islandsSelect, distValue, "NEW_SELECTION", "NOT_INVERT")
arcpy.AddMessage('APs selected that are too Close to Islands')

# Process: Add Field (5)
arcpy.AddField_management(apTooCloseLyr, "Near_Island", "SHORT", "", "", "", "", "NULLABLE", "NON_REQUIRED", "")

# Process: Calculate Field (6)
arcpy.CalculateField_management(apTooCloseLyr, "Near_Island", "1", "VB", "")
arcpy.AddMessage('New Field Created and Calcualted that shows 1 for lines Near Island')

# Process: Select
apTooCloseIsland=os.path.join(EDHgdb, "AP_Too_Close_Islands")
arcpy.Select_analysis(apTooCloseLyr, apTooCloseIsland, "\"Near_Island\" =1")
arcpy.AddMessage('APs too close to Islands Selected and Saved')

# Copy Output Files to Evaluation GDB
tooCloseAll=os.path.join(EDHmain, 'QC6_'+ "AP_Too_Close_Islands")
arcpy.CopyFeatures_management('AP_Too_Close_Islands', tooCloseAll)
arcpy.AddMessage('AP_Too_Close_Islands is Copied from Temp to Main GDB')

# Calculate Number of Features
count=arcpy.GetCount_management(tooCloseAll)
arcpy.AddMessage('Calculated Number of Features for Report')

# Add Results to Report
reportWksp=os.path.join(EDHwksp, 'EDH_QC_Assessment_TempDir/Report')
with open(reportWksp+'/Report.txt','a') as fout:
    fout.write('Results for QC6 AP Close To Islands\n\n')
    now = datetime.datetime.now()
    currentTime = now.strftime("%B:%d:%Y:%H:%M:%S")
    fout.write('Report Created: {}\n'.format(currentTime))
    fout.write('{}    Created with {} features\n\n\n\n'.format(os.path.basename(tooCloseAll),count))
arcpy.AddMessage('Report Updated')
os.startfile(reportWksp+'/Report.txt')