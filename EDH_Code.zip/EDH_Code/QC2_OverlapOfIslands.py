#Script Name:                   QC2_OverlapOfIslands.py
#Corresponding Script Tool:     QC2_OverlapOfIslands
#Purpose:                       To find Islands and Islands that contain EDH Lines 
#Methodology:                   Copy -> Union -> Select-> Intersect -> Copy -> Calculate -> WriteReport                                
#Author:                        Gardner Pierson, North Carolina State University, 03/2/2021


import sys,os,arcpy,datetime
arcpy.env.overwriteOutput=True

# Arguements

EDHwksp=sys.argv[1]#EDH_workspace


# Setting up the workspace
EDHgdb=os.path.join(EDHwksp, "EDH_QC_Assessment_TempDir/tempQC2.gdb")
arcpy.env.workspace= EDHgdb
EDHmain=os.path.join(EDHwksp, "EDH_QC_Evaluation.gdb")
EDH_lines=os.path.join(EDHmain,'EDH_Lines')
EDH_polys=os.path.join(EDHmain,'EDH_polygons')
arcpy.AddMessage('Workspace Set Up')

### Analysis

# Copy
islandsTemp=os.path.join(EDHgdb, "island_temp")
arcpy.Copy_management(EDH_polys, islandsTemp, "FeatureClass")
arcpy.AddMessage('EDH Data Copied to Temp GDB')


# Union of EDH Poly With Self
islandsUnion=os.path.join(EDHgdb, "Islands_Union")
inFeatures=['island_temp','island_temp']
arcpy.Union_analysis(inFeatures, islandsUnion, "ALL", "", "NO_GAPS")
arcpy.AddMessage('Union of EDH Polygons with Itself Completed')

# Select Islands
islandsSelect=os.path.join(EDHgdb, "Islands")
arcpy.Select_analysis('Islands_Union', islandsSelect, "\"FID_island_temp\" < 0 AND \"Shape_Area\" < 1000000")
arcpy.AddMessage('Islands Created')

# Intersect Islands with EDH Lines
islandsOutput=os.path.join(EDHgdb, "Islands_with_Lines")
arcpy.Intersect_analysis(["Islands",EDH_lines], islandsOutput, "ALL", "", "INPUT")
arcpy.AddMessage('Islands Sucessfully Intersected with EDH Lines to find Islands with Lines')

# Copy Output Files to Evaluation GDB
islandsOut=os.path.join(EDHmain, 'QC2_'+ "Islands")
islandsLinesOut=os.path.join(EDHmain, 'QC2_'+ "Islands_with_Lines")
arcpy.CopyFeatures_management("Islands", islandsOut)
arcpy.CopyFeatures_management("Islands_with_Lines", islandsLinesOut)
arcpy.AddMessage('Islands and Islands with Lines Copied from Temp to Main GDB')

# Calculate Number of Features
count1=arcpy.GetCount_management(islandsOut)
count2=arcpy.GetCount_management(islandsLinesOut)
arcpy.AddMessage('Calculated Number of Features for Report')

# Add Results to Report
reportWksp=os.path.join(EDHwksp, 'EDH_QC_Assessment_TempDir/Report')
with open(reportWksp+'/Report.txt','a') as fout:
    fout.write('Results for QC2 Overlap Of Islands\n\n')
    now = datetime.datetime.now()
    currentTime = now.strftime("%B:%d:%Y:%H:%M:%S")
    fout.write('Report Created: {}\n'.format(currentTime))
    fout.write('{}    Created with {} features\n'.format(os.path.basename(islandsOut),count1))
    fout.write('{}    Created with {} features\n\n\n\n'.format(os.path.basename(islandsLinesOut),count2))
arcpy.AddMessage('Report Updated')
os.startfile(reportWksp+'/Report.txt')
