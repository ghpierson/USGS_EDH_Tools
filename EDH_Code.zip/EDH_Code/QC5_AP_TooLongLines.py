#Script Name:                   QC5_AP_TooLongLines.py
#Corresponding Script Tool:     QC5 AP Too Long Lines
#Purpose:                       Takes the overlapping sections from QC4 and checks to see if they intersect with buffered streams;
#                               Also, it connects the AP segments and reports ones that are over a certain length
#Author:                        Gardner Pierson, North Carolina State University, 03/8/2021
#

### Imports
import sys,os,arcpy
arcpy.env.overwriteOutput=True

# Script arguments

EDHwksp=sys.argv[1]#EDH_workspace

thresholdValue=float(sys.argv[2]) # Threshold Distance Value in Map Units 

segLength=float(sys.argv[3]) # Script Reports connected APs over this length

### Setting up the workspace
EDHmain=os.path.join(EDHwksp, "EDH_QC_Evaluation.gdb")
EDHgdb=os.path.join(EDHwksp, "EDH_QC_Assessment_TempDir/tempQC5.gdb")
arcpy.env.workspace= EDHgdb
arcpy.AddMessage('Workspace Set')

### Analysis

# Process: Clip
edhLines=os.path.join(EDHmain, "EDH_Lines")
areasToClose=os.path.join(EDHmain, "QC4_AP_areas_too_close")
edhLinesClip=os.path.join(EDHgdb, "EDH_Lines_Clip")
arcpy.Clip_analysis(edhLines, areasToClose, edhLinesClip)
arcpy.AddMessage('EDH Lines Clipped to Areas Too Close created in QC4')

# Process: Multipart To Singlepart
apMultiOut=os.path.join(EDHgdb, "ap_multi")
arcpy.MultipartToSinglepart_management(edhLinesClip, apMultiOut)
arcpy.AddMessage('Mutlipart to Singlepart Complete')

# Process: Add Field
arcpy.AddField_management(apMultiOut, "Unit", "SHORT", "", "", "", "", "NULLABLE", "NON_REQUIRED")

# Process: Calculate Field
arcpy.CalculateField_management(apMultiOut, "Unit", "1", "VB")
arcpy.AddMessage('Units Field Added and Calcualted')

# Process: Spatial Join
apSpatialJoin=os.path.join(EDHgdb, "ap_multi_SpatialJoin")
arcpy.SpatialJoin_analysis(apMultiOut, areasToClose, apSpatialJoin, "JOIN_ONE_TO_ONE", "KEEP_ALL","", "INTERSECT")
arcpy.AddMessage('Singlepart Output Joined to Areas too Close')

# Process: Select (2)
apTooClose=os.path.join(EDHgdb, "AP_Too_Close_all")
query= "SHAPE_Length > {0}".format(thresholdValue)
arcpy.Select_analysis(apSpatialJoin, apTooClose, query)
arcpy.AddMessage('Selected Lines over Threshold Distance')

# Process: Unsplit Line
apUnsplit=os.path.join(EDHgdb, "ap_multi_SpatialJoin_Unsplit")
arcpy.UnsplitLine_management(apTooClose, apUnsplit)
arcpy.AddMessage('Lines Unsplit')

# Process: Select (4)
query2= "\"SHAPE_length\" > {0}".format(segLength)
outputstring= "AP_Too_close_{0}m_long".format(int(segLength))
apTooCloseOutput=os.path.join(EDHgdb, outputstring)
arcpy.Select_analysis(apUnsplit,apTooCloseOutput, query2)
arcpy.AddMessage('Selected Lines over Threshold Length')

# Copy Output Files to Evaluation GDB

tooCloseAll=os.path.join(EDHmain, 'QC5_'+ "AP_Too_Close_all")
arcpy.CopyFeatures_management('AP_Too_Close_all', tooCloseAll)
tooCloseSeg=os.path.join(EDHmain, 'QC5_'+ outputstring)
arcpy.CopyFeatures_management(outputstring, tooCloseSeg)
arcpy.AddMessage('AP_Too_Close_all and AP_Too_close_{}m_long Created'.format(int(segLength)))

# Calculate Number of Features
count1=arcpy.GetCount_management(tooCloseAll)
count2=arcpy.GetCount_management(tooCloseSeg)
arcpy.AddMessage('Calculated Number of Features for Report')

# Add Results to Report
reportWksp=os.path.join(EDHwksp, 'EDH_QC_Assessment_TempDir/Report')
with open(reportWksp+'/Report.txt','a') as fout:
    fout.write('Results for QC5 AP Too Long Lines\n\n')
    now = datetime.datetime.now()
    currentTime = now.strftime("%B:%d:%Y:%H:%M:%S")
    fout.write('Report Created: {}\n'.format(currentTime))
    fout.write('{}    Created with {} features\n'.format(os.path.basename(tooCloseAll),count1))
    fout.write('{}    Created with {} features\n\n\n\n'.format(os.path.basename(tooCloseSeg),count2))
arcpy.AddMessage('Report Updated')
os.startfile(reportWksp+'/Report.txt')

