#Script Name:                   QC4_AP_TooClose_AllPolys.py
#Corresponding Script Tool:     QC4 AP Too Close All Polys
#Purpose:                       Finds Areas where APs are to close to Polygons
#Methodology:                   Select EDH Polys -> Polygon to Polyline -> Buffer -> Select -> Buffer-> Select-> Copy->WriteReport                              
#Author:                        Gardner Pierson, North Carolina State University, 03/8/2021

import sys,os,arcpy,datetime
arcpy.env.overwriteOutput=True

# Script arguments

EDHwksp=sys.argv[1]#EDH_workspace
distVal=float(sys.argv[2])#Threshold Dist
bufferDis=sys.argv[3]

### Setting up the workspace
EDHmain=os.path.join(EDHwksp, "EDH_QC_Evaluation.gdb")
EDHgdb=os.path.join(EDHwksp, "EDH_QC_Assessment_TempDir/tempQC4.gdb")
arcpy.env.workspace= EDHgdb
arcpy.AddMessage('Workspace Set Up')

### Analysis

# Select EDH Polygons that are Not Areas of Complex Channels 
edhPolys=os.path.join(EDHmain, "EDH_Polygons")
arcpy.Select_analysis(edhPolys, 'wbs', "FCode <> 53700")
arcpy.AddMessage('Selected EDH Polygons that are Not Areas of Complex Channels')

# Convert Selected Polygons to Polylines
arcpy.PolygonToLine_management('wbs', 'wb_as_lines', "IDENTIFY_NEIGHBORS")
arcpy.AddMessage('Selected Polygons Converted to Polylines')

# Buffer 
try:
    arcpy.Buffer_analysis('wb_as_lines', 'polylinbuffinside', bufferDis, "FULL", "ROUND", "NONE", "", "PLANAR")
    arcpy.AddMessage('wb_as_lines Buffered to create polylinebuffinside')
except:
    message = 'wb_as_lines not created. This could be because wbs is empty and has no lines to extract. \
Script will now exit as there will be no output. Be sure to check for Null Values in your Data'
    print message 
    arcpy.arcpy.AddError(message)
    sys.exit(0)
    
# Select APs
edhLines=os.path.join(EDHmain, "EDH_Lines")
query="FCode = 55800 AND SHAPE_Length> {0}".format(distVal)
arcpy.Select_analysis(edhLines, 'lines_AP', query)
arcpy.AddMessage('APs Selected')

# Buffer APs
arcpy.Buffer_analysis('lines_AP', 'AP_buffs1', "1 Meters", "FULL", "FLAT", "LIST", "FCode", "PLANAR")
arcpy.AddMessage('APs Buffered')

# Union: Find the areas where the buffers overlap
inputUnion=['polylinbuffinside','AP_buffs1']
arcpy.Union_analysis(inputUnion, 'AP_Edge_Union', "ONLY_FID", "", "GAPS")
arcpy.AddMessage('Areas Identified Where Buffers Overlap (AP_Edge_Union Createdin Temp GDB)')

# Select the APs that are too Close to Polygons
arcpy.Select_analysis('AP_Edge_Union', 'AP_areas_too_close', "FID_polylinbuffinside >0 AND FID_AP_buffs1 > 0")
arcpy.AddMessage('APs That Are Too Close to Polygons Selected')

# Copy Output Files to Evaluation GDB
APout=os.path.join(EDHmain, 'QC4_'+ "AP_areas_too_close")
arcpy.CopyFeatures_management('AP_areas_too_close', APout)
arcpy.AddMessage('AP_areas_too_close is Copied to the Main GDB')

# Calculate Number of Features
count=arcpy.GetCount_management(APout)
arcpy.AddMessage('Calculated Number of Features for Report')

# Add Results to Report
reportWksp=os.path.join(EDHwksp, 'EDH_QC_Assessment_TempDir/Report')
with open(reportWksp+'/Report.txt','a') as fout:
    fout.write('Results for QC4 AP Too Close All Polys\n\n')
    now = datetime.datetime.now()
    currentTime = now.strftime("%B:%d:%Y:%H:%M:%S")
    fout.write('Report Created: {}\n'.format(currentTime))
    fout.write('{}    Created with {} features\n\n\n\n'.format(os.path.basename(APout),count))
arcpy.AddMessage('Report Updated')
os.startfile(reportWksp+'/Report.txt')
