#Script Name:                   QC1_Bad_APs_and_Streams_in_Poly.py
#Corresponding Script Tool:     QC1 Bad APs and Streams in Poly
#Purpose:                       To find APs outside of Polys and non AP EDH Lines inside of Polys
#Methodology:                   Erase-> Clip-> Select-> Copy-> Calculate-> WriteReport                               
#Author:                        Gardner Pierson, North Carolina State University, 02/22/2021

##imports
import sys,os,arcpy,datetime
arcpy.env.overwriteOutput=True

#arguements

EDHwksp=sys.argv[1]#EDH_workspace
    
# Set up Paths
EDHgdb=os.path.join(EDHwksp, "EDH_QC_Assessment_TempDir/tempQC1.gdb")
arcpy.env.workspace= EDHgdb
EDHmain=os.path.join(EDHwksp, "EDH_QC_Evaluation.gdb")
arcpy.AddMessage('Paths Set')

# Erase
EDH_lines=os.path.join(EDHmain,'EDH_Lines')
EDH_polys=os.path.join(EDHmain,'EDH_polygons')
eraseOut=os.path.join(EDHgdb, "LinesTracking_Erase")
arcpy.Erase_analysis(EDH_lines, EDH_polys, eraseOut, "")
arcpy.AddMessage('Erase Completed Sucessfully')

# Clip
clipOut=os.path.join(EDHgdb, "LinesTracking_Clip")
arcpy.Clip_analysis(EDH_lines, EDH_polys, clipOut, "")
arcpy.AddMessage('Clip Completed Sucessfully')

#select Non-APs inside of Polygons
linesPolyOut=os.path.join(EDHgdb, "Lines_in_polys")
arcpy.Select_analysis('LinesTracking_Clip', linesPolyOut, "\"FCode\" <> 55800 ")
arcpy.AddMessage('Non-APs Inside of Polygons Selected and Exported to temp as Lines_in_polys')

# select APs outside of Polys
outsidePolyOut=os.path.join(EDHgdb, "AP_outside_polys")
arcpy.Select_analysis('LinesTracking_Erase', outsidePolyOut, "\"FCode\" = 55800 ")
arcpy.AddMessage('APs Outside of Polygons Selected and Exported to temp as AP_outside_polys')

# Copy Output Files to Evaluation GDB
outsidePolyOut=os.path.join(EDHmain,'QC1_'+ "AP_outside_polys")
linesPolyOut=os.path.join(EDHmain, 'QC1_'+ "Lines_in_polys")
arcpy.CopyFeatures_management('AP_outside_polys', outsidePolyOut)
arcpy.CopyFeatures_management('Lines_in_polys', linesPolyOut)
arcpy.AddMessage('AP_outside_polys_ and Lines_in_polys copied from Temp to Main GDB')

# Calculate Number of Features
apPoly=arcpy.GetCount_management(outsidePolyOut)
linesPoly=arcpy.GetCount_management(linesPolyOut)
arcpy.AddMessage('Calculated Number of Features for Report')

# Add Results to Report
reportWksp=os.path.join(EDHwksp, 'EDH_QC_Assessment_TempDir/Report')
with open(reportWksp+'/Report.txt','a') as fout:
    fout.write('Results for QC1 Bad APs and Streams in Polys\n\n')
    now = datetime.datetime.now()
    currentTime = now.strftime("%B:%d:%Y:%H:%M:%S")
    fout.write('Report Created: {}\n'.format(currentTime))
    fout.write('{}    Created with {} features\n'.format(os.path.basename(outsidePolyOut),apPoly))
    fout.write('{}    Created with {} features\n\n\n\n'.format(os.path.basename(linesPolyOut),linesPoly))
arcpy.AddMessage('Report Updated')
os.startfile(reportWksp+'/Report.txt')